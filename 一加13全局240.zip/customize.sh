ui_print "




—— 刷入の时间$(date '+%g-%m-%d %H:%M:%S')


—— 面具版本$MAGISK_VER_CODE


—— 面具代号$MAGISK_VER




"
echo "

id=一加人


name=一加13 全局240采样率


version=全局240采样率


versionCode=26403


author=一加人


description=一加13全局240采样率 [刷入时间：$(date '+%g-%m-%d %H:%M:%S')] [等候您的重启…]
" > $MODPATH/module.prop
echo "$(date '+%g-%m-%d %H:%M:%S')" > $MODPATH/time