#!/system/bin/sh
Murong_Naiyi=${0%/*}
su -c sh $Murong_Naiyi/start_later.rc
ro.oplus.audio.soundx_enhance_support=1